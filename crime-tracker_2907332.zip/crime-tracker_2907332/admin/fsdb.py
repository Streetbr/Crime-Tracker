import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

class DataSet:
    __APP_INITIATED = False
    __db = None

    def __init__(self, type, ref=None, data=None):
        self.type = type        # 0-collection 1-document
        self.ref = ref
        self.data = data
        self.name = None
        if data is not None:
            self.name = data.id
        elif ref is not None:
            self.name = ref.id
        
    def __initiateObject__(self):
        if self.data == None:
            self.data = self.ref.get()        
    @staticmethod
    def getPathFromRoot(path = None):
        DataSet.__init_app()
        if path:
            return FSCollection(DataSet.__db.collection(path))
        else:
            l = list()
            collections = DataSet.__db.collections()
            for collection in collections:
                l.append(FSCollection(collection))
            return l
    @staticmethod
    def new(path):
        col = DataSet.__db.collection()
        return col

    @staticmethod
    def __init_app():
        if not DataSet.__APP_INITIATED:
            cred = credentials.Certificate("serviceAccountKey.json")
            default_app = firebase_admin.initialize_app(cred)
            DataSet.__db = firestore.client()

        DataSet.__APP_INITIATED = True

class FSCollection(DataSet):
    def __init__(self, ref=None, data=None):
        super().__init__(0, ref, data)

    def get(self, path = None, new_doc = False):
        if path:
            return FSDocument(ref = self.ref.document(path))
        else:
            if new_doc:
                return FSDocument(ref = self.ref.document())
            else:
                l = list()
                docRefs = self.ref.stream()
                for docRef in docRefs:
                    l.append(FSDocument(data=docRef))
                return l
    def __getitem__(self, key, **args):
        return self.get(key)
    def __setitem__(self, key, value):
        pass

    def __repr__(self):
        return "Collection: "+self.name


class FSDocument(DataSet):
    def __init__(self, ref=None, data=None):
        super().__init__(1, ref, data)
    def get(self, path = None):
        if path:
            return FSCollection(ref = self.ref.collection(path))
        else:
            l = list()
            collections = self.ref.collections()
            for collection in collections:
                l.append(FSCollection(ref = collection))
            return l
    def __getitem__(self, key, **args):
        self.__initiateObject__()
        return self.data.get(key)
    def __setitem__(self, key, value):
        #TODO use update method if exists
        self.ref.set({key:value})

    def __repr__(self):
        return "Document: "+self.name

    def setData(self, data):
        self.ref.set(data)

class FSRoot(type):
    @staticmethod
    def get(path=None):
        return DataSet.getPathFromRoot(path)
    @staticmethod        
    def new(path):
        return DataSet.new(path)
    # @staticmethod        
    # def __getitem__(self, key, **args):
    #     return FSRoot.get(key)

class Officer:
    def __init__(self, badge, name):
        self.badge=badge
        self.name=name

class Gang:
    def __init__(self, name, members):
        self.name=name
        self.members = members

class Area:
    def __init__(self, country, city, lat, lng):
        self.country=country
        self.city=city
        self.lat=float(lat)
        self.lng=float(lng)

class Vehicle:
    def __init__(self, licensePlate, owner):
        self.licensePlate=licensePlate
        self.owner=owner

class Witness:
    def __init__(self, witnessName):
        self.witnessName=witnessName