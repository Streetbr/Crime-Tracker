import csv
import sys
from fsdb import FSRoot
from fsdb import FSCollection
from fsdb import FSDocument
from datetime import datetime
from fsdb import Area
from fsdb import Officer
from fsdb import Witness
from fsdb import Gang
from fsdb import Vehicle

import math

def getCSV(filename):
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        results = list()
        for row in csv_reader:
            results.append(row)
        return results


def addCities():
    print("Adding areas",end='')
    data = getCSV('data/cities.csv') 
    cities = FSRoot.get('areas')
    for cityData in data:
        country = cityData[0]
        name = cityData[1]
        lat = float(cityData[2])
        lng = float(cityData[3])
        lbl = country+", "+name
        key=country+"."+name
        cities[key].setData({'city-name':name, 'country':country, 'gps':{'lat':lat, 'lng':lng},'key':key, 'label':lbl})
        print(".", end="")
        sys.stdout.flush()
    print("done")

def addOfficers():
    print("Adding officers",end='')
    data = getCSV('data/officers.csv') 
    officers = FSRoot.get('officers')
    for officerData in data:
        badgeNumber = officerData[0]
        officerName = officerData[1]
        officers[badgeNumber].setData({'badge':badgeNumber, 'name':officerName})
        print(".", end="")
        sys.stdout.flush()
    print("done")

def addGangs():
    print("Adding gangs",end='')
    data = getCSV('data/gangs.csv') 
    groups = FSRoot.get('groups')
    for groupData in data:
        groupId = groupData[0]
        groupName = groupData[1]
        memberList = groupData[2:]
        groups[groupName].setData({'name':groupName, 'members':memberList})
        print(".", end="")
        sys.stdout.flush()
    print("done")    

def getNearestArea(cityList, lat, lng):
    minCity = None
    minValue = -1
    for city in cityList:
        d = math.sqrt(((city[1]['lat']-lat)**2)+((city[1]['lng']-lng)**2))
        if minCity is None or minValue>d:
            minValue = d
            minCity = city
    return minCity

def getAreaDataList():
    areas = FSRoot.get('areas').get()
    areaDataList = list()
    
    for area in areas:
        areaDataList.append([area.name, area['gps']])
    return areaDataList

def addMeetings():
    areaDataList = getAreaDataList()
    print("Adding gatherings",end='')
    data = getCSV('data/gatherings.csv') 
    areas = FSRoot.get('areas')
    for gatheringData in data:
        groupName = gatheringData[0]

        gdate = gatheringData[1]
        gtime = gatheringData[2]
        dtstr = gdate+" "+gtime
        gdatetime = datetime.strptime(dtstr, '%m/%d/%y %H:%M:%S')
        dtstr = gdatetime.strftime("%m-%d-%y %H:%M:%S")
        gduration = int(gatheringData[3])
        badgeno =gatheringData[4]
        witness =gatheringData[5]
        area =gatheringData[6]
        lat =float(gatheringData[7])
        lng = float(gatheringData[8])
        nearestArea = getNearestArea(areaDataList, lat, lng)
        gtype = gatheringData[9]
        gnotes = gatheringData[10:]
        if len(gnotes)==1 and gnotes[0]=="":
            gnotes=[]
        gdata = dict()
        gdata['when']=gdatetime
        gdata['duration']=gduration
        gdata['badge']=badgeno
        gdata['evidence'] = {'type':'WITNESS','data':witness}
        gdata['gps']={'lat':lat,'lng':lng}
        gdata['gathering-type']=gtype
        gdata['notes']=gnotes
        gdata['gang-name'] = groupName
        areas[nearestArea[0]].get('gatherings')[dtstr].setData(gdata)
        print(".", end="")
        sys.stdout.flush()
    print("done") 

def addVehicles():
    print("Adding vehicles",end='')
    data = getCSV('data/vehicles.csv') 
    vehicles = FSRoot.get('vehicles')
    for vehicleData in data:
        licensePlate = vehicleData[0]
        ownerName = vehicleData[1]
        vehicles[licensePlate].setData({'license-plate':licensePlate, 'owner':ownerName})
        print(".", end="")
        sys.stdout.flush()
    print("done")

def addVehicleViolations():
    print("Adding traffic violations",end='')
    data = getCSV('data/trafficviolations.csv') 
    areaDataList = getAreaDataList()

    areas = FSRoot.get('areas')
    for gatheringData in data:
        licensePlate = gatheringData[0]

        vdate = gatheringData[1]
        vtime = gatheringData[2]
        dtstr = vdate+" "+vtime
        vdatetime = datetime.strptime(dtstr, '%m/%d/%y %H:%M:%S')
        dtstr = vdatetime.strftime("%m-%d-%y %H:%M:%S")

        area = gatheringData[3]
        lat =float(gatheringData[4])
        lng = float(gatheringData[5])
        nearestArea = getNearestArea(areaDataList, lat, lng)
        violationType = gatheringData[6]
        violationData1 = gatheringData[7]
        violationData2 = gatheringData[8]
        evidenceType = gatheringData[9]
        evidenceData = gatheringData[10]

        vnotes = gatheringData[11:]
        if len(vnotes)==1 and vnotes[0]=="":
            vnotes=[]
        gdata = dict()
        gdata['when']=vdatetime
        gdata['evidence'] = {'type':evidenceType,'data':evidenceData}
        gdata['violation-type'] = {'type':violationType,'data1':violationData1,'data2':violationData2}

        gdata['gps']={'lat':lat,'lng':lng}
        gdata['notes']=vnotes
        gdata['license-plate']=licensePlate
        areas[nearestArea[0]].get('traffic-violations')[dtstr].setData(gdata)
        print(".", end="")
        sys.stdout.flush()
    print("done") 


# addOfficers()
addGangs()
# addVehicles()
addCities()
addMeetings()
addVehicleViolations()
