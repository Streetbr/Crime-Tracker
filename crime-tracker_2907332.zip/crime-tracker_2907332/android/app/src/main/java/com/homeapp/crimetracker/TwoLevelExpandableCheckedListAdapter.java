package com.homeapp.crimetracker;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.graphics.Typeface;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckedTextView;

import com.google.firebase.firestore.DocumentSnapshot;

public class TwoLevelExpandableCheckedListAdapter<T>  extends BaseExpandableListAdapter {

    private Context context;
    private List<String> expandableListTitle;
    private Map<String, List<Pair<String,T>>> expandableListDetail;
    Map<String, List<String>> initialSelectedList;

    public TwoLevelExpandableCheckedListAdapter(Context context, List<String> expandableListTitle,
                                                Map<String, List<Pair<String,T>>> expandableListDetail, Map<String, List<String>> initialSelectedList) {
        this.context = context;
        this.expandableListTitle = expandableListTitle;
        this.expandableListDetail = expandableListDetail;
        this.initialSelectedList = initialSelectedList;
    }

    @Override
    public Object getChild(int listPosition, int expandedListPosition) {
        return this.expandableListDetail.get(this.expandableListTitle.get(listPosition))
                .get(expandedListPosition);
    }

    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }

    @Override
    public View getChildView(int listPosition, final int expandedListPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        final String expandedListText = ((Pair<String, DocumentSnapshot>) getChild(listPosition, expandedListPosition)).first;
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_checked_item, null);
        }
        CheckedTextView expandedListTextView = (CheckedTextView) convertView
                .findViewById(R.id.expandedListCheckedItem);
        expandedListTextView.setText(expandedListText);
        String titleTxt = expandableListTitle.get(listPosition);
        expandedListTextView.setChecked((initialSelectedList.size()==0 || (initialSelectedList.containsKey(titleTxt) && initialSelectedList.get(titleTxt).contains(expandedListText))));
        return convertView;
    }

    @Override
    public int getChildrenCount(int listPosition) {
        return this.expandableListDetail.get(this.expandableListTitle.get(listPosition))
                .size();
    }

    @Override
    public Object getGroup(int listPosition) {
        return this.expandableListTitle.get(listPosition);
    }

    @Override
    public int getGroupCount() {
        return this.expandableListTitle.size();
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }

    @Override
    public View getGroupView(int listPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        String listTitle = (String) getGroup(listPosition);
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_checked_group, null);
        }
        CheckedTextView listTitleTextView = (CheckedTextView) convertView.findViewById(R.id.listCheckedTitle);
        listTitleTextView.setTypeface(null, Typeface.BOLD);
        listTitleTextView.setText(listTitle);
        listTitleTextView.setChecked((initialSelectedList.size()==0 || (initialSelectedList.containsKey(listTitle) && initialSelectedList.get(listTitle).size()==getChildrenCount(listPosition))));

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }
}