package com.homeapp.crimetracker.model;

import java.util.Date;

public class CrimeReport {
    int id;
    String description;
    MapLocation location;
    CrimeType mainCrimeType;
    CrimeCategory crimeCategory;
    Date timeOfOccurrence;

    public Date getTimeOfOccurrence() {
        return timeOfOccurrence;
    }

    public void setTimeOfOccurrence(Date timeOfOccurrence) {
        this.timeOfOccurrence = timeOfOccurrence;
    }

    public String getDescription() {
        return description;
    }

    public MapLocation getLocation() {
        return location;
    }

    public CrimeType getMainCrimeType() {
        return mainCrimeType;
    }

    public CrimeCategory getCrimeCategory() {
        return crimeCategory;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setLocation(MapLocation location) {
        this.location = location;
    }

    public void setMainCrimeType(CrimeType mainCrimeType) {
        this.mainCrimeType = mainCrimeType;
    }

    public void setCrimeCategory(CrimeCategory crimeCategory) {
        this.crimeCategory = crimeCategory;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public CrimeReport(int id, CrimeCategory crimeCategory, CrimeType mainCrimeType, MapLocation location, String description, Date timeOfOccurrence) {
        this.id = id;
        this.description = description;
        this.location = location;
        this.mainCrimeType = mainCrimeType;
        this.crimeCategory = crimeCategory;
        this.timeOfOccurrence = timeOfOccurrence;
    }

}
