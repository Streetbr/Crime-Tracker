package com.homeapp.crimetracker;

import android.util.Pair;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.google.firebase.firestore.DocumentSnapshot;
import com.homeapp.crimetracker.model.SpeedingViolationData;

import java.util.List;

//This class will create fragment objects for each speeding violation data
public class SpeedingViolationDataCollectionAdapter extends FragmentStatePagerAdapter {
    List<SpeedingViolationData> violationDataList;
    public SpeedingViolationDataCollectionAdapter(@NonNull FragmentManager fm, int behavior, List<SpeedingViolationData> violationDataList) {
        super(fm, behavior);
        this.violationDataList=violationDataList;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return SpeedingViolationDataFragment.newInstance(violationDataList, position);
    }

    @Override
    public int getCount() {
        return this.violationDataList.size();
    }
}
