package com.homeapp.crimetracker.model;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class SpeedingViolationData {
    String country;

    public String getCountry() {
        return country;
    }

    public String getCity() {
        return city;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public Map<String, String> getEvidence() {
        return evidence;
    }

    public Map<String, Double> getGps() {
        return gps;
    }

    public Map<String, String> getType() {
        return type;
    }

    public List<String> getNotes() {
        return notes;
    }

    public Date getWhen() {
        return when;
    }

    String city;
    String licensePlate;
    Map<String, String> evidence;
    Map<String, Double> gps;
    Map<String, String> type;
    List<String> notes;
    Date when;

    public String getAreaLabel() {
        return areaLabel;
    }

    String areaLabel;

    public SpeedingViolationData(String country, String city, String areaLabel, DocumentSnapshot doc){
        this.country=country;
        this.city=city;
        this.areaLabel = areaLabel;
        licensePlate=doc.getString("license-plate");
        evidence=(Map<String, String>)doc.get("evidence");
        gps=(Map<String, Double>)doc.get("gps");
        type=(Map<String, String>)doc.get("violation-type");
        when=doc.getDate("when");
        notes=(List<String>)doc.get("notes");
    }
}
