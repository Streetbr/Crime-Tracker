package com.homeapp.crimetracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class HomeActivity extends AppCompatActivity {
    ListView lvMain;
    FloatingActionButton btnSignOut;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.home_toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setTitle("");
        setTitle("");
        lvMain = findViewById(R.id.lvMain);
        btnSignOut = findViewById(R.id.btnSignOut);

        //Create a image list and text list for the menu in home screen
        List<String> menuItemTitle = new ArrayList<>();
        List<Integer> menuItemIcons = new ArrayList<>();

        final int ggT = menuItemTitle.size();
        menuItemTitle.add("Gang Gatherings \n(last 24 hrs)");
        menuItemIcons.add(R.drawable.gang_time1);

        final int svT = menuItemTitle.size();
        menuItemTitle.add("Speeding Violations \n(last 24 hrs)");
        menuItemIcons.add(R.drawable.speeding_time1 );

        final int gg = menuItemTitle.size();
        menuItemTitle.add("Gang Gatherings");
        menuItemIcons.add(R.drawable.gang1 );

        final int sv = menuItemTitle.size();
        menuItemTitle.add("Speeding Violations");
        menuItemIcons.add(R.drawable.speeding1 );

        final int filtr = menuItemTitle.size();
        menuItemTitle.add( "Filter Settings");
        menuItemIcons.add(R.drawable.filter1 );

//        final int sgnout = menuItemTitle.size();
//        menuItemTitle.add( "Sign out");
//        menuItemIcons.add(R.drawable.signout1);

        //Setup the menu items on the listview
        CustomAdapter adapter = new CustomAdapter(this,  menuItemTitle, menuItemIcons);
        lvMain.setAdapter(adapter);

        lvMain.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = null;
                Calendar cal = Calendar.getInstance();
                cal.setTime(new Date());
                cal.add(Calendar.DATE, -1);

                //Check which menu item was clicked and launch appropriate action
                if (i==gg) intent= new Intent(HomeActivity.this, LatestGangGatheringListActivity.class);
                else if (i==sv) intent = new Intent(HomeActivity.this, SpeedingViolationsListActivity.class);
                else if (i==filtr) intent = new Intent(HomeActivity.this, SettingsActivity.class);
                else if (i==ggT) {
                    intent = new Intent(HomeActivity.this, LatestGangGatheringListActivity.class);
                 // FOr 24 Hour thing
                    intent.putExtra(LatestGangGatheringListActivity.PARAMETER_FROM_WHEN, cal.getTime().getTime());
                }else if (i==svT) {
                    intent = new Intent(HomeActivity.this, SpeedingViolationsListActivity.class);
                    intent.putExtra(SpeedingViolationsListActivity.PARAMETER_FROM_WHEN, cal.getTime().getTime());
                }else intent = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //sign out and launch the login window
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(HomeActivity.this, LoginActivity.class));
            }
        });
    }
}