package com.homeapp.crimetracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Pair;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TableRow;
import android.widget.TextView;
import android.graphics.Color;
import android.widget.TableLayout;
import android.graphics.Typeface;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class LatestGangGatheringListActivity extends AppCompatActivity implements OnMapReadyCallback{
    public static String PARAMETER_FROM_WHEN = "from.when";
    TableLayout tl;
    FirebaseFirestore db;
    List<Pair<String, DocumentSnapshot>> gatheringList = null;
    boolean isDetailsView = true;
    boolean isMapsInitiated = false;
    private GoogleMap gmap;
    MapView mapView;
    ScrollView detailListControlView;
    Bundle tmpSavedInstanceState;
    FloatingActionButton fab;
    Date fromWhen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gang_gathering_list);

        //Check to see if there's a time limit
        Long v = getIntent().getLongExtra(LatestGangGatheringListActivity.PARAMETER_FROM_WHEN, -1);
        if (v==null){

            //load all time data
            Calendar instance = Calendar.getInstance();
            instance.set(1900, 1,1,1,1,1);
            fromWhen = instance.getTime();
        }else{
            fromWhen = new Date();
            fromWhen.setTime(v);
        }
        tmpSavedInstanceState = savedInstanceState;
        tl = findViewById(R.id.tblCrimeReports);
        db = FirebaseFirestore.getInstance();

        setTitle("Gang Sightings");
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        detailListControlView = findViewById(R.id.detailsListControl);
        fab = findViewById(R.id.fab);

        //Switch between map view and details view
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mapView = findViewById(R.id.mapView);
                View mapViewLayout = findViewById(R.id.mapViewLayout);

                if (isDetailsView){
                    //switch to map view
                    detailListControlView.setVisibility(View.GONE);
                    mapViewLayout.setVisibility(View.VISIBLE);
                    if (!isMapsInitiated) {
                        //If its the first time, we'll initialize
                        mapView.onCreate(tmpSavedInstanceState);
                        mapView.getMapAsync(LatestGangGatheringListActivity.this);
                        mapView.onResume();
                        isMapsInitiated=true;
                    }
                    fab.setImageResource(android.R.drawable.ic_dialog_dialer);
                }else{
                    //switch to details view
                    detailListControlView.setVisibility(View.VISIBLE);
                    mapViewLayout.setVisibility(View.GONE);
                    fab.setImageResource(android.R.drawable.ic_dialog_map);
                }
                isDetailsView =!isDetailsView;
            }
        });
        addHeadersToTable();
        addDataToTable();
    }

    private List<Pair<String, Marker>> markers;
    boolean markersInText = false;
    public void onMapReady(GoogleMap googleMap) {
        gmap = googleMap;
        gmap.getUiSettings().setZoomControlsEnabled(true);
        gmap.getUiSettings().setZoomGesturesEnabled(true);
        gmap.getUiSettings().setCompassEnabled(true);
        gmap.getUiSettings().setAllGesturesEnabled(true);
        gmap.getUiSettings().setMapToolbarEnabled(true);

        //Check to see if app has permission to get current location
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED) {
            gmap.setMyLocationEnabled(true);
            gmap.getUiSettings().setMyLocationButtonEnabled(true);
        } else {
            //Ask for permission for current location
            Toast.makeText(this, "No permisison to see user location", Toast.LENGTH_LONG).show();
            ActivityCompat.requestPermissions(this, new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    1337);
        }
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm a");
        markers = new ArrayList<>();
        LatLngBounds.Builder builder = LatLngBounds.builder();

        //create markers for each gang sighting
        for(Pair<String, DocumentSnapshot> d: gatheringList){
            DocumentSnapshot doc = d.second;
            final Calendar when = Calendar.getInstance();
            when.setTime(doc.getDate("when"));
            final Map<String, Double> gps = (Map<String, Double>) doc.get("gps");

            LatLng loc = new LatLng(gps.get("lat"), gps.get("lng"));
            builder.include(loc);

            MarkerOptions position = new MarkerOptions().position(loc);

            position=position.title(doc.getString("gang-name") +" ("+sdf.format(when.getTime())+")");
            Marker marker = gmap.addMarker(position);
            markers.add(new Pair<>(doc.getString("gang-name"), marker));
        }

        //Open the gang details screen
        gmap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                System.out.println(marker.getPosition());
                GangGatheringDataActivity.documentListPlaceholder = gatheringList;
                Intent intent = new Intent(LatestGangGatheringListActivity.this, GangGatheringDataActivity.class);
                int index = 0;
                for(Pair<String, Marker> d: markers){
                    if (marker.equals(d.second)){
                        break;
                    }
                    index++;
                }
                intent.putExtra(GangGatheringDataActivity.CRIME_GANG_GATHERING_ID_PARAMETER, index);
                startActivity(intent);
            }
        });

        //adjust the map camera to contain all the markers
        gmap.moveCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 10));

        gmap.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {
            @Override
            public void onCameraMove() {
                //We'll change the markers to more descriptive markers as we zoom in
                boolean zoomedIn = gmap.getCameraPosition().zoom > 6;
                if ((zoomedIn && markersInText) || (!zoomedIn && !markersInText)){
                    return;
                }
                markersInText = zoomedIn;
                for(Pair<String, Marker> d: markers){
                    if (zoomedIn) {
                        d.second.setIcon(BitmapDescriptorFactory.fromBitmap(Utilities.generateBitmapFromText(d.first, 50, Color.BLACK)));
                    }else{
                        d.second.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
                    }
                    d.second.setAnchor(0.5f, 1);
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_scrolling, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void addHeadersToTable(){
        //dynamically create a header in the table
        TableRow tr = new TableRow(this);
        tr.addView(createHeaderCell("")); //Actions
        tr.addView(createHeaderCell("Gang Name"));
        tr.addView(createHeaderCell("When"));
        tr.addView(createHeaderCell("Area"));
        tr.setBackgroundColor(Color.parseColor("#7851a9"));
        tl.addView(tr, new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
    }

    private TextView createHeaderCell(String headerText){
        TextView headerCell = new TextView(this);
        headerCell.setText(headerText);
        headerCell.setTextColor(Color.WHITE);
        headerCell.setTextSize(16);
        headerCell.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT);
        params.setMargins(10, 10, 50, 10);
        headerCell.setLayoutParams(params);
        headerCell.setPadding(5, 5, 5, 0);
        return headerCell;
    }
    public void addDataToTable(){
        //dynamically create the table rows with the gang data
        CollectionReference groups = db.collection("groups");
        List<String> gangsNames = (List<String>)SessionData.getUserData().get("gangs");
        if (gangsNames==null){
            //if user doesn't hv a preference we show all gangs
            groups.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            addGangSightingEntry(document.getString("name"));
                        }
                    } else {
                        Toast.makeText(LatestGangGatheringListActivity.this, "Error retrieving gang list: "+task.getException(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else{
            //only show gang sighting data of users preference
            for(String gangName: gangsNames){
                addGangSightingEntry(gangName);
            }
        }
    }

    private void addGangSightingEntry(final String gangName) {
        if (gatheringList==null){
            gatheringList = new ArrayList<>();
        }else{
            gatheringList.clear();
        }
        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        //Query for latest gang data for the gangName
        db.collectionGroup("gatherings").whereEqualTo("gang-name",gangName).whereGreaterThan("when", fromWhen).orderBy("when", Query.Direction.DESCENDING).limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            //                        Task<QuerySnapshot> querySnapshotTask = document.getReference().collection("meetings").limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    for (QueryDocumentSnapshot doc : task.getResult()) {
                        final DocumentSnapshot tmpDoc=doc;
                        //create a row for the table
                        final TableRow tr = new TableRow(LatestGangGatheringListActivity.this);
                        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                        doc.getReference().getParent().getParent().get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                DocumentSnapshot areaDoc = task.getResult();
                                final int index = gatheringList.size();
                                gatheringList.add(new Pair<>(areaDoc.getString("country")+":"+areaDoc.getString("city-name"),tmpDoc));
                                ImageView btnView = createImageView(R.drawable.details_icon1, new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
//                                Toast.makeText(LatestGangGatheringListActivity.this, Integer.toString(index), Toast.LENGTH_SHORT).show();
                                        GangGatheringDataActivity.documentListPlaceholder = gatheringList;
                                        Intent intent = new Intent(LatestGangGatheringListActivity.this, GangGatheringDataActivity.class);
                                        intent.putExtra(GangGatheringDataActivity.CRIME_GANG_GATHERING_ID_PARAMETER, index);
                                        startActivity(intent);
                                    }
                                });
                                //adding values for the table row
                                tr.addView(btnView);
                                tr.addView(createCellText(gangName));
                                tr.addView(createCellText(dateFormat.format(tmpDoc.getDate("when"))));
                                tr.addView(createCellText(areaDoc.getString("country")+":"+areaDoc.getString("city-name")));

                            }});
                        tr.setBackgroundColor((tl.getChildCount() % 2 == 0)? Color.parseColor("#eddbff"):Color.WHITE);
                        tl.addView(tr, new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    }

                }else{
                    Toast.makeText(LatestGangGatheringListActivity.this, "Error retrieving gang data for : "+gangName+" ERROR: "+task.getException(), Toast.LENGTH_LONG).show();
                    task.getException().printStackTrace();
                }
            }
        });
    }

    private TextView createCellText(String cellText){
        //elements in a table is nothing but other controls. we'll create a textview for a table cell
        TextView cellData = new TextView(this);
        cellData.setText(cellText);
        cellData.setTextColor(Color.BLACK);
        TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT);
        params.setMargins(10, 10, 50, 10);
        cellData.setLayoutParams(params);
        cellData.setPadding(5, 5, 5, 5);
        return cellData;
    }
    private Button createCellButton(String cellText, View.OnClickListener listener){
        //elements in a table is nothing but other controls. we'll create a button for a table cell
        Button cellData = new Button(this);
        cellData.setText(cellText);
        cellData.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        cellData.setPadding(5, 5, 5, 5);
        cellData.setOnClickListener(listener);
        return cellData;
    }
    private ImageView createImageView(int imageResource, View.OnClickListener listener){
        //elements in a table is nothing but other controls. we'll create a Imageview for a table cell
        ImageView cellData = new ImageView(this);
        cellData.setImageResource(imageResource);
        cellData.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        cellData.getLayoutParams().height=100;
        cellData.getLayoutParams().width=100;

        cellData.setPadding(5, 5, 5, 5);
        cellData.setOnClickListener(listener);
        return cellData;
    }


    //following functions are needed to support the google maps life cycle
    @Override
    protected void onResume() {
        super.onResume();
        if (!isDetailsView) mapView.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!isDetailsView) mapView.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!isDetailsView) mapView.onStop();
    }



    @Override
    protected void onPause() {
        if (!isDetailsView) mapView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (!isDetailsView) mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (!isDetailsView) mapView.onLowMemory();
    }
}