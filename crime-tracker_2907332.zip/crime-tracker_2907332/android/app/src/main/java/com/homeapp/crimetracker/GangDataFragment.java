package com.homeapp.crimetracker;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.util.Pair;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * This class represents The Fragment UI for viewing Gang Data
 */
public class GangDataFragment extends Fragment {

    //key value to used to save the index of the array of documents
    public static final String DOC_LIST_INDEX_PARAM = "doc.list.index.parameter";

    //array of documents containing gang data
    List<Pair<String, DocumentSnapshot>> docList;

    WebView wv;
    ScrollingViewTableController controller;
    DocumentSnapshot doc;
    View view;
    FirebaseFirestore db;


    private int id;

    public GangDataFragment() {}

    public static GangDataFragment newInstance(List<Pair<String, DocumentSnapshot>> docList, int index) {
        //Create a new fragment with the relevant Gang Data document index
        GangDataFragment fragment = new GangDataFragment();
        Bundle args = new Bundle();
        args.putInt(DOC_LIST_INDEX_PARAM, index);
        fragment.setArguments(args);
        fragment.setDocList(docList);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            //retrieve and save the index
            id = getArguments().getInt(DOC_LIST_INDEX_PARAM);
        }
        //initialize the firestore database client instance
        db = FirebaseFirestore.getInstance();
    }

    protected void setDocList(List<Pair<String, DocumentSnapshot>> docList){
        this.docList=docList;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_gang_data, container, false);
        wv = view.findViewById(R.id.scrollingView);
        controller = new ScrollingViewTableController(wv);
        if (id==-1){
            id=0;
        }
        populateCrimeReportData(id);

        return view;
    }

    //This function will read the data from the cloud firestore document and view it.
    private void populateCrimeReportData(int id) {
        final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm a");
        doc = docList.get(id).second;

        Map<String, String> evidence = (Map<String, String>) doc.get("evidence");
        final Calendar when = Calendar.getInstance();
        when.setTime(doc.getDate("when"));
        Calendar until =(Calendar)  when.clone();
        until.add(Calendar.MINUTE, doc.getLong("duration").intValue());
        final Map<String, Double> gps = (Map<String, Double>) doc.get("gps");
        List<String> notes = (List<String>)  doc.get("notes");

        //Add gang data to the web view
        controller.addRow("Gang name", doc.getString("gang-name"));
        controller.addRow("Officer badge", doc.getString("badge"));
        controller.addRow("Happened at", sdf.format(when.getTime()));
        controller.addRow("Meeting ended", sdf.format(until.getTime()));
        controller.addRow(evidence.get("type"), evidence.get("data"));
        controller.addRow("Gathering behavior", doc.getString("gathering-type"));
        controller.addRow("Location", controller.createButton(docList.get(id).first, new ScrollingViewTableController.JSClickAction() {
            @Override
            public void performClick() {
                //Open the maps with the gps coordinates
                Intent intent = new Intent(view.getContext(), MapsActivity.class);
                intent.putExtras(new Bundle());
                intent.putExtra(MapsActivity.MARKER_LATITUDE_PARAMETER, new double[]{gps.get("lat")});
                intent.putExtra(MapsActivity.MARKER_LONGITUDE_PARAMETER, new double[]{gps.get("lng")});
                intent.putExtra(MapsActivity.MARKER_NAMES_PARAMETER, new String[]{doc.getString("gang-name") +" ("+sdf.format(when.getTime())+")"});

                startActivity(intent);
                Toast.makeText(view.getContext(), gps.get("lat").toString() + "," + gps.get("lng").toString(), Toast.LENGTH_SHORT).show();
            }
        }));
        if (notes.size()>0) {
            controller.addRow("Notes", notes.toArray(new String[]{}));
        }
        controller.addRow("", controller.createButton("See Gang Memberlist", new ScrollingViewTableController.JSClickAction() {
            @Override
            public void performClick() {
                //Open a floating popup window and load the gang memberlist
                GangDataFragment.this.getActivity().runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        //Create the popup UI
                        LayoutInflater inflater = (LayoutInflater) view.getContext().getSystemService(view.getContext().LAYOUT_INFLATER_SERVICE);
                        View customView = inflater.inflate(R.layout.popup_info_screen, null);
                        Button closeButton = customView.findViewById(R.id.ib_close);
                        final ListView infoDataView = customView.findViewById(R.id.tvPopupData);

                        //Load the members list from the cloud database
                        db.collection("groups").document(doc.getString("gang-name")).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    final List<String> members = (List<String>) task.getResult().get("members");
                                    GangDataFragment.this.getActivity().runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            ArrayAdapter<String> test = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_list_item_1,members);
                                            infoDataView.setAdapter(test);
                                        }
                                    });
                                }
                            }
                        });

                        final PopupWindow infoPopupWindow = new PopupWindow(
                                customView,
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT
                        );
                        if (Build.VERSION.SDK_INT >= 21) {
                            infoPopupWindow.setElevation(5.0f);
                        }

                        //Copy the name in to clipboard
                        infoDataView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                ClipboardManager clipboard = (ClipboardManager) view.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                                ClipData clip = ClipData.newPlainText("Member Name", infoDataView.getItemAtPosition(i).toString());
                                clipboard.setPrimaryClip(clip);
                                Toast.makeText(view.getContext(),"Copied to clipboard",Toast.LENGTH_SHORT).show();
                            }
                        });

                        //close the popup ui
                        closeButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                infoPopupWindow.dismiss();
                            }
                        });

                        //show the popup ui
                        infoPopupWindow.showAtLocation(view.findViewById(R.id.fgd_layout), Gravity.CENTER, 0, 0);
                    }
                });
            }
        }));
        controller.updateText();

    }
}