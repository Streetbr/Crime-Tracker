package com.homeapp.crimetracker;

import androidx.appcompat.app.AppCompatActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {
    EditText emailId, password;
    Button btnSignUp;
    TextView tvSignIn;
    EditText etPersonName;
    FirebaseAuth mFirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        mFirebaseAuth = FirebaseAuth.getInstance();
        emailId = findViewById(R.id.editTextTextEmailAddress);
        password = findViewById(R.id.editTextTextPassword);
        btnSignUp= findViewById(R.id.btnSignUp);
        tvSignIn = findViewById(R.id.textView);
        etPersonName = findViewById(R.id.etPersonName);
        btnSignUp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                final String email = emailId.getText().toString();
                String pwd = password.getText().toString();
                if (email.isEmpty() && pwd.isEmpty()){
                    Toast.makeText(SignUpActivity.this, "Required Fields Are Empty!!!",Toast.LENGTH_SHORT).show();
                }else if (email.isEmpty()){
                    emailId.setError("Please enter email address");
                    emailId.requestFocus();
                }else  if (pwd.isEmpty()){
                    password.setError("Please enter your password");
                    password.requestFocus();
                }else  if (etPersonName.getText().toString().isEmpty()){
                    etPersonName.setError("Please enter your name");
                    etPersonName.requestFocus();
                } else {
                    mFirebaseAuth.createUserWithEmailAndPassword(email, pwd).addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                Toast.makeText(SignUpActivity.this, "Sign Up Unsuccessful. Please try again."+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            }else{
                                SessionData.initialize(new SessionData.OnInitializedListener() {
                                    @Override
                                    public void sessionInitialized() {
                                        SessionData.getUserData().getReference().update("name", etPersonName.getText().toString());
                                        SessionData.updateUserData("name", etPersonName.getText().toString());
                                        startActivity(new Intent(SignUpActivity.this, HomeActivity.class));
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
        tvSignIn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            }
        });
    }
}