package com.homeapp.crimetracker.model;

public class MapLocation {
    double longitude;
    double latitude;

    public MapLocation() {
    }

    public MapLocation(double longitude, double latitude) {
        this.longitude = longitude;
        this.latitude = latitude;
    }


}
