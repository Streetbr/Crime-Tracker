package com.homeapp.crimetracker;

import android.annotation.SuppressLint;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

//This class is responsible for creating an html table to be viewed on a WebView controller
public class ScrollingViewTableController {
    WebView wv;
    String styleTxt = "<style>/* DivTable.com */\n" +
            ".divTable{\n" +
            "\tdisplay: table;\n" +
            "\twidth: 100%;\n" +
            "}\n" +
            ".divTableRow {\n" +
            "\tdisplay: table-row;\n" +
            " \tfont-size: 14px;\n" +
            "}\n" +
            ".divTableHeading {\n" +
            "\tbackground-color: #EEE;\n" +
            "\tdisplay: table-header-group;\n" +
            "}\n" +
            ".divTableCell, .divTableHead {\n" +
//            "\tborder: 1px solid #999999;\n" +
            "\tdisplay: table-cell;\n" +
            "\tpadding: 3px 10px;\n" +
            "}\n" +
            ".divTableCell1 {\n" +
            "\twidth: 30%;\n" +
            "\tfont-weight: bold;\n" +
            "\tpadding-bottom: 20px;\n"+
            "}\n" +
            ".divTableCell2 {\n" +
            "\twidth: 70%;\n" +
            "}\n" +
            ".divTableHeading {\n" +
            "\tbackground-color: #EEE;\n" +
            "\tdisplay: table-header-group;\n" +
            "\tfont-weight: bold;\n" +
            "}\n" +
            ".divTableFoot {\n" +
            "\tbackground-color: #EEE;\n" +
            "\tdisplay: table-footer-group;\n" +
            "\tfont-weight: bold;\n" +
            "}\n" +
            ".divTableBody {\n" +
            "\tdisplay: table-row-group;\n" +
            "}\n" +
            "ul { \n" +
            "              padding:0; margin: 0;\n" +
            "\t}" +
            ".button {\n" +
            "  background-color: white;\n" +
            "  border: solid 1px #eddbff;\n" +
            "  color: black;" +
            "  padding: 5px 10px;\n" +
            "  text-align: center;\n" +
            "  text-decoration: none;\n" +
            "  display: inline-block;\n" +
            "  font-size: 12px;\n" +
            "  margin: 4px 2px;\n" +
            "  cursor: pointer;\n" +
            "  border-radius: 5px;\n" +
            "  -webkit-transition-duration: 0.4s; /* Safari */\n" +
            "  transition-duration: 0.4s;\n" +
            "}\n" +
            "\n" +
            ".button1 {\n" +
            "  box-shadow: 0 1px 0 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);\n" +
            "}\n</style>";
    String tableTxtTemplate = "<div class=\"divTable\">\n" +
            "<div class=\"divTableBody\">\n" +
            "%s\n" +
            "</div>\n" +
            "</div>";
    String rowTxtTemplate ="<div class=\"divTableRow\">\n" +
            "<div class=\"divTableCell divTableCell1\">%s</div>\n" +
            "<div class=\"divTableCell divTableCell2\">%s</div>\n" +
            "</div>\n";

    String tableTxt = null;

    String bulletListTemplate="<ul>\n" +
            "  %s\n" +
            "</ul>";
    String bulletDataTemplate ="  <li>%s</li>\n";
    int objCounter = 0;

    public ScrollingViewTableController(WebView wv){
        this.wv = wv;
        wv.getSettings().setJavaScriptEnabled(true);
    }

    //Add a row the table with 2nd column content as a bullet point list
    public void addRow(String column1, String[] list) {
        String bulletList = bulletListTemplate;
        for (String s: list){
            String bulletData = String.format(bulletDataTemplate, s) + "%s";
            bulletList = String.format(bulletList, bulletData);
        }
        bulletList = String.format(bulletList, "");
        addRow(column1, bulletList);
    }

    //Add a row the table
    public void addRow(String column1, String column2){
        if (tableTxt==null){
            tableTxt= tableTxtTemplate;
            objCounter=0;
        }
        String rowTxt = String.format(rowTxtTemplate, column1, column2);
        rowTxt += "%s";
        tableTxt = String.format(tableTxt, rowTxt);
    }

    //create an html button and link its click activity to a function
    public String createButton(String caption, JSClickAction jsFuncs){
        objCounter++;
        String objName = "obj"+objCounter;
        final JSClickAction tmpJSFuncs = jsFuncs;
        wv.addJavascriptInterface(new Object(){

            @JavascriptInterface
            public void performClick(){
                tmpJSFuncs.performClick();
            }
        },objName);
        String buttonText="<button class=\"button button1\" onclick=\""+objName+".performClick();\"> "+caption+"</button>";
//        String buttonText = "<href onclick="+objName+".performClick(); \" > "+caption+" </href>";
        return buttonText;
    }

    //Send the html text to the webview control
    public void updateText(){
        tableTxt = styleTxt+String.format(tableTxt, "");
        wv.loadData(tableTxt, "text/html", "UTF-8");
        tableTxt = null;
    }

    //the java interface which defines how the function to click looks like
    public interface JSClickAction{
        @JavascriptInterface
        public void performClick();
    }
}
