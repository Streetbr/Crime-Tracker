package com.homeapp.crimetracker;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;

import com.homeapp.crimetracker.model.SpeedingViolationData;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SpeedingViolationDataFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SpeedingViolationDataFragment extends Fragment {
    //key value to used to save the index of the array of documents
    public static final String DOC_LIST_INDEX_PARAM = "doc.list.index.parameter";
    public static List<SpeedingViolationData> violationDataListPlaceholder;


    List<SpeedingViolationData> violationDataList;
    WebView wv;
    ScrollingViewTableController controller;
    Toolbar toolbar;
    TextView titleText;
    int id;
    View view;
    public void setViolationDataList(List<SpeedingViolationData> violationDataList) {
        this.violationDataList = violationDataList;
    }
    public SpeedingViolationDataFragment() {
        // Required empty public constructor
    }

    public static SpeedingViolationDataFragment newInstance(List<SpeedingViolationData> violationDataLis, int id) {
        //Create a new fragment with the relevant Speeding violation Data document index
        SpeedingViolationDataFragment fragment = new SpeedingViolationDataFragment();
        Bundle args = new Bundle();
        args.putInt(DOC_LIST_INDEX_PARAM, id);
        fragment.setArguments(args);
        fragment.setViolationDataList(violationDataLis);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            //retrieve and save the index
            id = getArguments().getInt(DOC_LIST_INDEX_PARAM);
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_speeding_violation_data, container, false);
        wv = view.findViewById(R.id.scrollingView);
        controller = new ScrollingViewTableController(wv);
        if (id==-1){

        } else {
            populateCrimeReportData(id);
        }
        return view;
    }
    //This function will read the data from the cloud firestore document and view it.
    private void populateCrimeReportData(int id) {
        final SpeedingViolationData vd = violationDataList.get(id);
        final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm a");

        final Calendar when = Calendar.getInstance();
        when.setTime(vd.getWhen());

        List<String> notes = vd.getNotes();
        //Add Speeding violations data to the web view
        controller.addRow("License plate", vd.getLicensePlate());
        controller.addRow("Happened at", sdf.format(when.getTime()));
        controller.addRow(vd.getEvidence().get("type"), vd.getEvidence().get("data"));
        String typeData="";
        if (vd.getType().get("type").equalsIgnoreCase("SPEEDING")){
            controller.addRow("Speed Limit", vd.getType().get("data1") + " km/h");
            typeData = vd.getType().get("data2") + "km/h over the speed limit";
        }
        controller.addRow("Violation", typeData);
        controller.addRow("Location", controller.createButton(vd.getCity(), new ScrollingViewTableController.JSClickAction() {
            @Override
            public void performClick() {
                //Open the maps with the gps coordinates
                Intent intent = new Intent(view.getContext(), MapsActivity.class);
                intent.putExtras(new Bundle());
                intent.putExtra(MapsActivity.MARKER_LATITUDE_PARAMETER, new double[]{vd.getGps().get("lat")});
                intent.putExtra(MapsActivity.MARKER_LONGITUDE_PARAMETER, new double[]{vd.getGps().get("lng")});
                intent.putExtra(MapsActivity.MARKER_NAMES_PARAMETER, new String[]{vd.getLicensePlate()+" ("+sdf.format(when.getTime())+")"});

                startActivity(intent);
                Toast.makeText(view.getContext(), vd.getGps().get("lat").toString() + "," + vd.getGps().get("lng").toString(), Toast.LENGTH_SHORT).show();
            }
        }));

        if (notes.size()>0) {
            controller.addRow("Notes", notes.toArray(new String[]{}));
        }
        controller.updateText();

    }
}