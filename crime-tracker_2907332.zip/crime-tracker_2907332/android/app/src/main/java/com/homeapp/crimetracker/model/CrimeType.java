package com.homeapp.crimetracker.model;

public enum CrimeType {
    ASSAULT_AND_BATTERY,
    FALSE_IMPRISONMENT,
    KIDNAPPING,
    HOMICIDE,
    RAPE,
    THEFT,
    ARSON,
    WHITE_COLLAR,
    FALSE_PRETENSE,
    STOLEN_GOODS_RECEIPT,
    ATTEMPTED,
    SOLICITATION,
    CONSPIRACY,
    STATUTORY,                          //eg: DUI or selling alcohol to minor
}
