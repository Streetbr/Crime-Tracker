package com.homeapp.crimetracker.model;

public enum CrimeCategory {
    PERSONAL,
    PROPERTY,
    INCHOATE                            //crimes that were initiated but not brought to completion
}
