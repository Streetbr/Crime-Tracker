package com.homeapp.crimetracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Pair;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.homeapp.crimetracker.model.SpeedingViolationData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SpeedingViolationsListActivity extends AppCompatActivity  implements OnMapReadyCallback {
    public static String PARAMETER_FROM_WHEN = "from.when";

    FirebaseFirestore db;
    boolean isDetailsView = true;
    boolean isMapsInitiated = false;
    private GoogleMap gmap;
    MapView mapView;
    ExpandableListView expandableListView;
    LinearLayout expandedListLayout;
    FloatingActionButton fab;
    Bundle tmpSavedInstanceState;
    Map<String, List<SpeedingViolationData>> violationsList;
    TwoLevelExpandableListAdapter expandableListAdapter;
    List<String> expandableListTitle;
    Map<String, Map<String, Double>> areaLocation;
    Date fromWhen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speeding_violations_list);
        //Check to see if there's a time limit
        Long v = getIntent().getLongExtra(LatestGangGatheringListActivity.PARAMETER_FROM_WHEN, -1);
        if (v==null){
            //load all time data
            Calendar instance = Calendar.getInstance();
            instance.set(1900, 1,1,1,1,1);
            fromWhen = instance.getTime();
        }else{
            fromWhen = new Date();
            fromWhen.setTime(v);
        }
        db = FirebaseFirestore.getInstance();

        tmpSavedInstanceState = savedInstanceState;
        expandedListLayout = findViewById(R.id.vExpandedListLayout);
        expandableListView = findViewById(R.id.vExpandableListView);
        setTitle("Speeding Violations");
        Toolbar toolbar = (Toolbar) findViewById(R.id.vtoolbar);
        setSupportActionBar(toolbar);
        areaLocation = new HashMap<>();
        fab = (FloatingActionButton) findViewById(R.id.vfab);
        //Switch between map view and details view
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout mapViewLayout = findViewById(R.id.vMapViewLayout);

                if (isDetailsView){
                    //switch to map view
                    expandedListLayout.setVisibility(View.GONE);
                    mapViewLayout.setVisibility(View.VISIBLE);
                    mapView = findViewById(R.id.vMapView);

                    if (!isMapsInitiated) {
                        //If its the first time, we'll initialize
                        mapView.onCreate(tmpSavedInstanceState);
                        mapView.getMapAsync(SpeedingViolationsListActivity.this);
                        mapView.onResume();
                        isMapsInitiated=true;
                    }
                    fab.setImageResource(android.R.drawable.ic_dialog_dialer);
                }else{
                    //switch to details view
                    expandedListLayout.setVisibility(View.VISIBLE);
                    mapViewLayout.setVisibility(View.GONE);
                    fab.setImageResource(android.R.drawable.ic_dialog_map);
                }
                isDetailsView =!isDetailsView;
            }
        });
        Map<String, List<String>> supportedAreas = (Map<String, List<String>>)SessionData.getUserData().get("areas");
        violationsList = new HashMap<>();
        Task<QuerySnapshot> areasQuery;
        if (supportedAreas==null) {
            areasQuery = db.collection("areas").get();
            areasQuery.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    for (DocumentSnapshot areaDoc : task.getResult()) {
                        addViolationData(areaDoc);
                    }
                    setupExpandableListView();
                }
            });
        }else{
            List<String> areaList = new ArrayList<>();
            for(String countryName: supportedAreas.keySet()){
                for(String cityName: supportedAreas.get(countryName)){
                    areaList.add(countryName+"."+cityName);

                }
            }
//            areaDataRetrieveCounter = areaList.size();
            for(String key: areaList){
                db.collection("areas").document(key).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()){
                            addViolationData(task.getResult());
                        }

//                        checkAllAreaDataRetrieved();
                    }
                });
            }
        }

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
//                Toast.makeText(SpeedingViolationsListActivity.this, "i="+i+" i1="+i1, Toast.LENGTH_SHORT).show();
                SpeedViolationDataActivity.violationDataListPlaceholder = violationsList.get(expandableListTitle.get(i));
                Intent intent = new Intent(SpeedingViolationsListActivity.this, SpeedViolationDataActivity.class);
                intent.putExtra(SpeedViolationDataActivity.VIOLATION_LIST_AREA_PARAMETER, expandableListTitle.get(i));
                intent.putExtra(SpeedViolationDataActivity.VIOLATION_LIST_ID_PARAMETER, i1);
                startActivity(intent);
                return false;
            }

        });

    }

    private void setupExpandableListView() {
//        Toast.makeText(SpeedingViolationsListActivity.this, "Speeding violation data retrieved", Toast.LENGTH_SHORT).show();
        expandableListTitle = new ArrayList<String>(violationsList.keySet());
        expandableListAdapter = new TwoLevelExpandableListAdapter(SpeedingViolationsListActivity.this, expandableListTitle, violationsList);
        expandableListView.setAdapter(expandableListAdapter);
    }

    private void addViolationData(DocumentSnapshot areaDoc) {
        final String country = areaDoc.getString("country");
        final String city = areaDoc.getString("city-name");
        final String key = areaDoc.getString("key");
        final String lbl = areaDoc.getString("label");
        Map<String, Double> gps = (Map<String, Double>)areaDoc.get("gps");
        areaLocation.put(key, gps);
        Task<QuerySnapshot> trafficViolations = areaDoc.getReference().collection("traffic-violations").whereGreaterThan("when", fromWhen).orderBy("when", Query.Direction.DESCENDING).get();
        trafficViolations.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task2) {
                if (task2.isSuccessful()) {
                    for (DocumentSnapshot violationDoc : task2.getResult()) {
                        if (!violationsList.containsKey(key)){
                            violationsList.put(key, new ArrayList<SpeedingViolationData>());
                        }
                        violationsList.get(key).add(new SpeedingViolationData(country, city, lbl, violationDoc));
                        setupExpandableListView();
                    }
                }
            }
        });
    }

    private List<Marker> markers;
    boolean markersInText = false;
    public void onMapReady(GoogleMap googleMap) {
        System.out.println("On Map Ready called");
        gmap = googleMap;
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED) {
            gmap.setMyLocationEnabled(true);
            gmap.getUiSettings().setMyLocationButtonEnabled(true);
        } else {
            Toast.makeText(this, "No permission to see user location", Toast.LENGTH_LONG).show();
            ActivityCompat.requestPermissions(this, new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    1337);
            gmap.setMyLocationEnabled(true);
        }
        gmap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter(){

            @Override
            public View getInfoWindow(Marker marker) {

                return null;
            }

            @Override
            public View getInfoContents(Marker marker) {
                LinearLayout info = new LinearLayout(SpeedingViolationsListActivity.this);
                info.setOrientation(LinearLayout.VERTICAL);

                TextView title = new TextView(SpeedingViolationsListActivity.this);
                title.setTextColor(Color.BLACK);
                title.setGravity(Gravity.CENTER);
                title.setTypeface(null, Typeface.BOLD);
                title.setText(marker.getTitle());
                info.addView(title);
                if (marker.getSnippet()!=null && !marker.getSnippet().trim().equalsIgnoreCase("")) {
                    TextView snippet = new TextView(SpeedingViolationsListActivity.this);
                    snippet.setTextColor(Color.GRAY);
                    snippet.setText(marker.getSnippet());

                    info.addView(snippet);
                }
                return info;
            }
        });
        gmap.getUiSettings().setZoomControlsEnabled(true);
        gmap.getUiSettings().setZoomGesturesEnabled(true);
        gmap.getUiSettings().setMyLocationButtonEnabled(true);
        gmap.getUiSettings().setCompassEnabled(true);
        gmap.getUiSettings().setAllGesturesEnabled(true);
        gmap.getUiSettings().setMapToolbarEnabled(true);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy '|' hh:mm a");
        SimpleDateFormat sdfD = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat sdfT = new SimpleDateFormat("hh:mm a");
        markers = new ArrayList<>();
        LatLngBounds.Builder builder = LatLngBounds.builder();

        for(String areaName: violationsList.keySet()){
            List<SpeedingViolationData> speedingViolationData = violationsList.get(areaName);
//            d.second.setIcon(BitmapDescriptorFactory.fromBitmap(textAsBitmap(d.first, 50, Color.BLACK)));
            Map<String, Double> gps = areaLocation.get(areaName);
            LatLng loc = new LatLng(gps.get("lat"), gps.get("lng"));
            MarkerOptions position = new MarkerOptions().position(loc);
            position=position.title(String.valueOf(speedingViolationData.size())+" violation(s)");
            Marker marker = gmap.addMarker(position);
            List<Marker> violationMarkers = new ArrayList<>();
            marker.setTag(new Pair<String,List<Marker>>(areaName, violationMarkers));
            int i=0;
            for(SpeedingViolationData violationData: speedingViolationData){
                LatLng loc2 = new LatLng(violationData.getGps().get("lat"), violationData.getGps().get("lng"));
                MarkerOptions position2 = new MarkerOptions().position(loc2);
                Calendar when = Calendar.getInstance();
                when.setTime(violationData.getWhen());
                position2.icon(BitmapDescriptorFactory.fromBitmap(Utilities.generateBitmapFromText(sdfD.format(when.getTime()), 50, Color.BLACK)));
                position2=position2.title("License Plate: "+violationData.getLicensePlate());
                position2=position2.snippet("Occured at "+sdfT.format(when.getTime())+"\nVehicle was "+violationData.getType().get("type"));
                Marker marker2 = gmap.addMarker(position2);
                marker2.setTag(new Pair<Integer,Marker>(i, marker));
                marker2.setVisible(false);
                violationMarkers.add(marker2);
                i++;
            }
            builder.include(loc);
            markers.add(marker);
        }
        gmap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                if (!markers.contains(marker)) {
                    //only for individual violations we show the details page

                    Pair<Integer, Marker> violationMTag = (Pair<Integer, Marker>) marker.getTag();
                    Pair<String, Marker> areaMTag = (Pair<String, Marker>) violationMTag.second.getTag();

                    SpeedViolationDataActivity.violationDataListPlaceholder = violationsList.get(areaMTag.first);
                    Intent intent = new Intent(SpeedingViolationsListActivity.this, SpeedViolationDataActivity.class);
                    intent.putExtra(SpeedViolationDataActivity.VIOLATION_LIST_AREA_PARAMETER, areaMTag.first);
                    intent.putExtra(SpeedViolationDataActivity.VIOLATION_LIST_ID_PARAMETER, violationMTag.first);
                    startActivity(intent);
                }
            }
        });
        if (violationsList.size()>0) {
            gmap.moveCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 10));
        }
        gmap.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {
            @Override
            public void onCameraMove() {
                boolean zoomedIn = gmap.getCameraPosition().zoom > 10;
                if ((zoomedIn && markersInText) || (!zoomedIn && !markersInText)){
                    return;
                }
                markersInText = zoomedIn;
                for(Marker m: markers){
                    m.setVisible(!zoomedIn);
                    Pair<String, List<Marker>> markerTag = (Pair<String, List<Marker>>) m.getTag();
                    for(Marker m2: markerTag.second){
                        m2.setVisible(zoomedIn);
                        m2.setAnchor(0.5f, 1);
                    }
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_scrolling, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isDetailsView) mapView.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!isDetailsView) mapView.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!isDetailsView) mapView.onStop();
    }



    @Override
    protected void onPause() {
        if (!isDetailsView) mapView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (!isDetailsView) mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (!isDetailsView) mapView.onLowMemory();
    }
}