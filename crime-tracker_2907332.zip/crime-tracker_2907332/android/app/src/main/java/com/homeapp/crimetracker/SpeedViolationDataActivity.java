package com.homeapp.crimetracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.homeapp.crimetracker.model.SpeedingViolationData;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class SpeedViolationDataActivity extends AppCompatActivity {
    public static String VIOLATION_LIST_ID_PARAMETER = "violation_list__id";
    public static String VIOLATION_LIST_AREA_PARAMETER = "violation_list__area";

    public static List<SpeedingViolationData> violationDataListPlaceholder;
    List<SpeedingViolationData> violationDataList;
    ViewPager speedViolationViewPager;
    SpeedingViolationDataCollectionAdapter collectionAdapter;
    Toolbar toolbar;
    TextView titleText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speed_violations_data);

        int id = this.getIntent().getIntExtra(SpeedViolationDataActivity.VIOLATION_LIST_ID_PARAMETER, -1);
        String areaText = this.getIntent().getStringExtra(SpeedViolationDataActivity.VIOLATION_LIST_AREA_PARAMETER);
        toolbar =  findViewById(R.id.vdata_toolbar);
        setSupportActionBar(toolbar);
        violationDataList = violationDataListPlaceholder;
        titleText = findViewById(R.id.vdata_title);
        titleText.setText(areaText);
        speedViolationViewPager = findViewById(R.id.speedingViolationViewPager);
        collectionAdapter = new SpeedingViolationDataCollectionAdapter(getSupportFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT, violationDataList);
        speedViolationViewPager.setAdapter(collectionAdapter);
        speedViolationViewPager.setCurrentItem(id);
    }
}