package com.homeapp.crimetracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

public class GangGatheringDataActivity extends AppCompatActivity {
    //index to show the first gang data in a fragment
    public static String CRIME_GANG_GATHERING_ID_PARAMETER = "gang_gathering_id";

    //list of all the gang data to be passed via a static variable
    public static List<Pair<String, DocumentSnapshot>> documentListPlaceholder;
    List<Pair<String, DocumentSnapshot>> docList;

    ViewPager gangViewPager;
    GangDataCollectionAdapter collectionAdapter;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gang_gathering_data);
        int id = this.getIntent().getIntExtra(GangGatheringDataActivity.CRIME_GANG_GATHERING_ID_PARAMETER, -1);
        docList = documentListPlaceholder;

        toolbar =  findViewById(R.id.gang_toolbar);
        TextView titleText = findViewById(R.id.gang_title);

        setSupportActionBar(toolbar);
        titleText.setText("Gang Meeting");
        gangViewPager = findViewById(R.id.gangViewPager);
        collectionAdapter = new GangDataCollectionAdapter(getSupportFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT, docList);
        gangViewPager.setAdapter(collectionAdapter);
        gangViewPager.setCurrentItem(id);

    }

}