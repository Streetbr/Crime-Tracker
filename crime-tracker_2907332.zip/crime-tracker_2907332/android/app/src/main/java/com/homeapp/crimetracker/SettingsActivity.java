package com.homeapp.crimetracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingsActivity extends AppCompatActivity {
    ExpandableListView expandableListView;
    ListView lvGangList;
    Button btnSave;

    FirebaseFirestore db;

    DocumentSnapshot userData;

    //---Area list model
    ExpandableListAdapter expandableListAdapter;
    List<String> expandableListTitle;
    Map<String, List<Pair<String, DocumentSnapshot>>> areaList;
    Map<String, List<String>> userAreaMap;

    //---Gang list model
    List<String> gangList;
    List<String> userGangList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        areaList = new HashMap<>();
        expandableListView = (ExpandableListView) findViewById(R.id.expandableListView);
        btnSave = (Button) findViewById(R.id.btnSave);
        lvGangList = (ListView) findViewById(R.id.lvGangs);

        db = FirebaseFirestore.getInstance();
        userData = SessionData.getUserData();
        //retrieve current user preferences related to areas
        if (userData.get("areas")==null){
            userAreaMap = new HashMap<>();
        }else{
            userAreaMap = (Map<String, List<String>>)userData.get("areas");
        }
        //retrieve current user preferences related to gangs
        if (userData.get("gangs")==null){
            userGangList = new ArrayList<String>();
        }else{
            userGangList = (List<String>)userData.get("gangs");
        }
        Toast.makeText(SettingsActivity.this,"Loading saved user preference information. This might take a few seconds.", Toast.LENGTH_SHORT).show();

        //load and show areas and gangs with user preferences
        setupAreaLists();
        setupGangList();

        btnSave.setEnabled(true);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SettingsActivity.this,"Updating preferences...", Toast.LENGTH_SHORT).show();
                Map<String, Object> d = userData.getData();
                if (d==null){
                    d=new HashMap<>();
                }
                d.put("areas", userAreaMap);
                d.put("gangs", userGangList);
                SessionData.updateUserData(d);
                Toast.makeText(SettingsActivity.this,"Updating preferences...done", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        setTitle("Filtering Records");
    }

    private void setupAreaLists(){
        Task<QuerySnapshot> areasQuery = db.collection("areas").get();
        //retrieve all the areas list
        areasQuery.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    boolean firstTimePreference = userAreaMap.size()==0;
                    for (QueryDocumentSnapshot areaDoc : task.getResult()) {
                        String country = areaDoc.getString("country");
                        String city = areaDoc.getString("city-name");
                        if (!areaList.containsKey(country)){
                            areaList.put(country, new ArrayList<Pair<String, DocumentSnapshot>>());
                        }
                        //if this is the first time user is configuring area preferences by default we assume the user wants to see all areas
                        if (firstTimePreference) {
                            if (!userAreaMap.containsKey(country)) {
                                userAreaMap.put(country, new ArrayList<String>());
                            }
                            userAreaMap.get(country).add(city);
                        }
                        areaList.get(country).add(new Pair(city, areaDoc));
                    }

                    //load the areas lists and current user preferences in to the expandable list view control
                    expandableListTitle = new ArrayList<String>(areaList.keySet());
                    expandableListAdapter = new TwoLevelExpandableCheckedListAdapter<>(SettingsActivity.this, expandableListTitle, areaList, userAreaMap);
                    expandableListView.setAdapter(expandableListAdapter);
                    expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
                        @Override
                        public void onGroupExpand(int groupPosition) {
                            for(int i=0; i<expandableListTitle.size(); i++){
                                if (i!=groupPosition){
                                    expandableListView.collapseGroup(i);
                                }
                            }
                        }
                    });

                    expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                        @Override
                        public boolean onChildClick(ExpandableListView parent, View v,
                                                    int groupPosition, int childPosition, long id) {
                            CheckedTextView textView = (CheckedTextView)v.findViewById(R.id.expandedListCheckedItem);
                            textView.setChecked(!textView.isChecked());
                            areaItemCheckStateChanged(groupPosition, childPosition, textView.isChecked());
                            return true;
                        }
                    });

                    //we are using long press to select/unselect everything under a group
                    expandableListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                        @Override
                        public boolean onItemLongClick(AdapterView<?> adapter, View view, int pos, long id) {
//                            Toast.makeText(SettingsActivity.this, "Long pressed pos:"+pos+" id:"+id, Toast.LENGTH_SHORT).show();

                            if (id>=0){
                                CheckedTextView textView = view.findViewById(R.id.listTitle);
                                textView.setChecked(!textView.isChecked());
                                String countryName = expandableListTitle.get(pos);
                                userAreaMap.get(countryName).clear();
                                if (textView.isChecked()){
                                    for(Pair<String, ?> cData: areaList.get(countryName)){
                                        userAreaMap.get(countryName).add(cData.first);
                                    }
                                }
                                for(int i=0; i<areaList.get(countryName).size(); i++){
                                    expandableListAdapter.getChildView(pos, i,false, null, null);
                                }
                                return false;
                            }else{
                                return true;
                            }
                        }
                    });
                } else {
                    Toast.makeText(SettingsActivity.this, "Error retrieving area list: " + task.getException(), Toast.LENGTH_LONG).show();
                    task.getException().printStackTrace();
                }
            }
        });
    }


    private void setupGangList(){
        Task<QuerySnapshot> groupsQuery = db.collection("groups").get();
        gangList=new ArrayList<>();
        groupsQuery.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    boolean firstTimePreference = userGangList.size()==0;
                    for (QueryDocumentSnapshot areaDoc : task.getResult()) {
                        String gangName = areaDoc.getString("name");
                        if (firstTimePreference) {
                            userGangList.add(gangName);
                        }
                        gangList.add(gangName);
                    }

                    final ArrayAdapter<String> adapter=new ArrayAdapter<String>(SettingsActivity.this, android.R.layout.simple_list_item_multiple_choice, gangList);
                    lvGangList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                    lvGangList.setAdapter(adapter);
                    for(int i=0; i<adapter.getCount();i++){
                        String gangName = adapter.getItem(i);
                        lvGangList.setItemChecked(i, userGangList.contains(gangName));
                    }
                    lvGangList.refreshDrawableState();
                    lvGangList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        private View view;
                        @Override
                        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                            CheckedTextView textView = (CheckedTextView)view;
                            gangItemCheckStateChanged(i, textView.isChecked());
                            this.view = view;
                        }
                    });

                    expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                        @Override
                        public boolean onChildClick(ExpandableListView parent, View v,
                                                    int groupPosition, int childPosition, long id) {
                            CheckedTextView textView = (CheckedTextView)v.findViewById(R.id.expandedListCheckedItem);
                            textView.setChecked(!textView.isChecked());
                            areaItemCheckStateChanged(groupPosition, childPosition, textView.isChecked());
                            return true;
                        }
                    });

                    expandableListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                        @Override
                        public boolean onItemLongClick(AdapterView<?> adapter, View view, int pos, long id) {
                            Toast.makeText(SettingsActivity.this, "Long pressed pos:"+pos+" id:"+id, Toast.LENGTH_SHORT).show();

                            if (id>=0){
                                CheckedTextView textView = view.findViewById(R.id.listTitle);
                                textView.setChecked(!textView.isChecked());
                                String countryName = expandableListTitle.get(pos);
                                userAreaMap.get(countryName).clear();
                                if (textView.isChecked()){
                                    for(Pair<String, ?> cData: areaList.get(countryName)){
                                        userAreaMap.get(countryName).add(cData.first);
                                    }
                                }
                                for(int i=0; i<areaList.get(countryName).size(); i++){
                                    expandableListAdapter.getChildView(pos, i,false, null, null);
                                }
                                return false;
                            }else{
                                return true;
                            }
                        }
                    });
                } else {
                    Toast.makeText(SettingsActivity.this, "Error retrieving area list: " + task.getException(), Toast.LENGTH_LONG).show();
                    task.getException().printStackTrace();
                }
            }
        });
    }


    private void areaItemCheckStateChanged(int groupPosition, int childPosition, boolean checked) {
        String countryName = expandableListTitle.get(groupPosition);
        String cityName = areaList.get(countryName).get(childPosition).first;
        if (!userAreaMap.containsKey(countryName)){
            userAreaMap.put(countryName, new ArrayList<String>());
        }
        if (checked && !userAreaMap.get(countryName).contains(cityName)){
            userAreaMap.get(countryName).add(cityName);
        } else if (!checked && userAreaMap.get(countryName).contains(cityName)){
            userAreaMap.get(countryName).remove(cityName);
        }
    }
    private void gangItemCheckStateChanged(int position, boolean checked) {
        String gangName = gangList.get(position);
        if (checked && !userGangList.contains(gangName)){
            userGangList.add(gangName);
        } else if (!checked && userGangList.contains(gangName)){
            userGangList.remove(gangName);
        }
    }

}