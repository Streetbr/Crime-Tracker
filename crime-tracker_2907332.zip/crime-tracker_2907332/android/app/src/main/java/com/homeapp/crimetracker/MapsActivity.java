package com.homeapp.crimetracker;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    public static String MARKER_NAMES_PARAMETER = "marker.names";
    public static String MARKER_LATITUDE_PARAMETER = "marker.lat";
    public static String MARKER_LONGITUDE_PARAMETER = "marker.lng";
    double[] lat;
    double[] lng;
    String[] markerNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        lat = getIntent().getDoubleArrayExtra(MARKER_LATITUDE_PARAMETER);
        lng = getIntent().getDoubleArrayExtra(MARKER_LONGITUDE_PARAMETER);
        markerNames = getIntent().getStringArrayExtra(MARKER_NAMES_PARAMETER);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        //check if we have permission to access current location
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(true);
        } else {
            Toast.makeText(this, "No permisison to see user location", Toast.LENGTH_LONG).show();
            //ask for permission
            ActivityCompat.requestPermissions(this, new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    1337);
        }
        //add the list of markers
        for(int i=0; i<lat.length; i++){
            LatLng gps = new LatLng(lat[i], lng[i]);
            mMap.addMarker(new MarkerOptions().position(gps).title(markerNames[i]));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(gps,10 ));
        }

    }
}
