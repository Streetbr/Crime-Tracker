package com.homeapp.crimetracker;

import android.os.Bundle;
import android.util.Pair;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.List;

/**
 * This class generated Fragment Activities for swiping left/right Gang Data
 */
public class GangDataCollectionAdapter extends FragmentStatePagerAdapter {
    List<Pair<String, DocumentSnapshot>> docList;
    public GangDataCollectionAdapter(@NonNull FragmentManager fm, int behavior, List<Pair<String, DocumentSnapshot>> docList) {
        super(fm, behavior);
        this.docList=docList;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        //Create new fragment instance for Gang Data in index "position"
        return GangDataFragment.newInstance(docList, position);
    }

    @Override
    public int getCount() {
        return this.docList.size();
    }
}
