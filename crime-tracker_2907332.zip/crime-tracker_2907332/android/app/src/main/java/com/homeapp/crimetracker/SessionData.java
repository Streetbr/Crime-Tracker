package com.homeapp.crimetracker;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

//This class manages information relating to the current user session
public class SessionData {
    private static String userEmail = null;
    private static DocumentSnapshot userData = null;
    private static FirebaseAuth mFirebaseAuth;
    private static FirebaseFirestore db;
    private static boolean onetimeInitialized = false;
    public interface OnInitializedListener{
        public void sessionInitialized();
    }

    //initialize the services
    private static void init() {
        if (!onetimeInitialized) {
            db = FirebaseFirestore.getInstance();
            mFirebaseAuth = FirebaseAuth.getInstance();
        }
        onetimeInitialized=true;
    }

    //initialize the new user to the session
    public static void initialize(OnInitializedListener init){
        init();
        FirebaseUser currentUser = mFirebaseAuth.getCurrentUser();
        if (userEmail==null || userEmail!=currentUser.getEmail()){
            userEmail=currentUser.getEmail();
            retrieveUserDataFromDB(init);
        }else{
            init.sessionInitialized();
        }
    }

    private static void retrieveUserDataFromDB(final OnInitializedListener init) {
        //Retrieve user settings
        db.collection("users").document(userEmail).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    userData = task.getResult();
                    if (init!=null) init.sessionInitialized();
                }
            }});
    }

    public static DocumentSnapshot getUserData(){
        return userData;
    }

    public static void updateUserData(Map<String, ?> data){
        //Update user preferences
        getUserData().getReference().set(data, SetOptions.merge());
        retrieveUserDataFromDB(null);
    }

    public static< T > void updateUserData(String key,T value){
        Map<String, T> data = new HashMap<String, T>();
        data.put(key, value);
        updateUserData(data);
    }
}
