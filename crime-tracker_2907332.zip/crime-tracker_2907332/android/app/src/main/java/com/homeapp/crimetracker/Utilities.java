package com.homeapp.crimetracker;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class Utilities {
    //create a custom marker with text for google maps
    public static Bitmap generateBitmapFromText(String text, float textSize, int textColor) {
        float pointerHeight = 10;
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(textSize);
        paint.setColor(textColor);
        paint.setTextAlign(Paint.Align.LEFT);
        float baseline = -paint.ascent(); // ascent() is negative
        int width = (int) (paint.measureText(text) + 0.5f); // round
        int height = (int) (baseline + paint.descent() + 0.5f);
        Bitmap image = Bitmap.createBitmap(width, height+(int)(pointerHeight), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(image);

        Paint paintBackground = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintBackground.setColor(Color.parseColor("#eddbff"));
        canvas.drawRect(new Rect(0,0,width, height), paintBackground);
        paintBackground.setStyle(Paint.Style.STROKE);
        paintBackground.setColor(Color.BLACK);
        canvas.drawRect(new Rect(0,0,width, height), paintBackground);

        Paint paintPoint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintPoint.setColor(Color.RED);
        paintPoint.setStrokeWidth(pointerHeight);
        canvas.drawCircle(width/2, height, 10, paintPoint);

        canvas.drawText(text, 0, baseline, paint);
        return image;
    }
}
